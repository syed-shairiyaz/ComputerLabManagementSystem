from flask import Blueprint, render_template
from datetime import date

from app.models import (
    Student,
    Teacher,
    Attendance,
    ComputerSystem
)

main = Blueprint("main", __name__)


@main.route("/")
def home():
    return render_template("index.html")


@main.route("/admin/login")
def admin_login():
    return render_template("auth/admin_login.html")


@main.route("/student/login")
def student_login():
    return render_template("auth/student_login.html")


@main.route("/admin/dashboard")
def admin_dashboard():

    total_students = Student.query.count()

    total_teachers = Teacher.query.count()

    total_systems = ComputerSystem.query.count()

    today_attendance = Attendance.query.filter_by(date=date.today()).count()

    return render_template(
        "admin/dashboard.html",
        total_students=total_students,
        total_teachers=total_teachers,
        total_systems=total_systems,
        today_attendance=today_attendance
    )