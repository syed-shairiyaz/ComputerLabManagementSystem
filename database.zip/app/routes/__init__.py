from .main import main
from .student_routes import student_bp
from .teacher_routes import teacher_bp